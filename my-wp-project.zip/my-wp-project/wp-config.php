<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */
//define('WP_CONTENT_DIR', $_SERVER['DOCUMENT_ROOT'] . '/careo');
//define('WP_CONTENT_URL', 'http://localhost/my-wp-project/careo');
// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'my-wp-project' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         ';?6CR[#5v6~qSQ/<fxSpSE: kx`:P`cXjBvhY-%tKWl85#[dETys[WV*aIgZdkX/' );
define( 'SECURE_AUTH_KEY',  '&@N6!dA<_I:*CM eSl[Qv8kuDb0$57cF7d#V{,&>q;Z!w<x:b>F_%WVz>SgkxtG-' );
define( 'LOGGED_IN_KEY',    'o4&+QnO(G7k4M0Mh/7wmpkf:!NLaDTG|YdTP}^-tvtf%iC.(Uv^d)0r-M}R?)6DO' );
define( 'NONCE_KEY',        'P{wNql0#EJn.ryYP:gc`(qtK(8qXS^isi[t^bw=X?,jq][%;*3bAu8 j_Xk]i>1S' );
define( 'AUTH_SALT',        '[@H1>=2B!Dl%E~yRVTUTo%)N+jpr18<wu:2|1QktYgVfS7NZeJ[=N]Oxf;>.oARH' );
define( 'SECURE_AUTH_SALT', '*4u(0rvr!y}*j2<t?|W9(FJ]0s^M%$J$/wE)you?9PGp*sBd>pK4wqi~!)+D(V`x' );
define( 'LOGGED_IN_SALT',   'lF}^V$5DM,z}j^P)9uiFyHHRf#O>Tle$oH;C #k*&j}e})xEpS*|885Q^#!4IHbL' );
define( 'NONCE_SALT',       'Q& %ET@gk(Yb4RwHY2+3:=Z?C~]24k]$e,>bg 8+jn%t`e{3V)mIno@7nRu`P.fP' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', true );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/* Multisite */
define('WP_ALLOW_MULTISITE', true);

define('MULTISITE', true);
define( 'SUBDOMAIN_INSTALL', false );
define( 'DOMAIN_CURRENT_SITE', 'localhost' );
define( 'PATH_CURRENT_SITE', '/my-wp-project/' );
define( 'SITE_ID_CURRENT_SITE', 1 );
define( 'BLOG_ID_CURRENT_SITE', 1 );

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
